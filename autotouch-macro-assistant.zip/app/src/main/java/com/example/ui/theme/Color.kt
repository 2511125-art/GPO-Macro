package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val ImmersiveBackground = Color(0xFF0F111A)
val ImmersiveSurface = Color(0xFF1B1D29)
val ImmersiveSurfaceBorder = Color(0x1AFFFFFF) // 10% white border

val ImmersiveIndigo = Color(0xFF6366F1)
val ImmersiveIndigoDark = Color(0xFF3730A3)
val ImmersiveEmerald = Color(0xFF34D399)
val ImmersiveEmeraldBg = Color(0xFF065F46)
val ImmersiveCrimson = Color(0xFFEF4444)
val ImmersiveSky = Color(0xFF38BDF8)

val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)
