package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val ImmersiveColorScheme = darkColorScheme(
    primary = ImmersiveIndigo,
    onPrimary = Color.White,
    primaryContainer = ImmersiveIndigoDark,
    onPrimaryContainer = Color.White,
    secondary = ImmersiveEmerald,
    onSecondary = Color.Black,
    tertiary = ImmersiveSky,
    background = ImmersiveBackground,
    onBackground = TextPrimary,
    surface = ImmersiveSurface,
    onSurface = TextPrimary,
    surfaceVariant = Color(0xFF242738),
    onSurfaceVariant = TextSecondary,
    outline = ImmersiveSurfaceBorder
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true,
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = ImmersiveColorScheme,
        typography = Typography,
        content = content
    )
}
