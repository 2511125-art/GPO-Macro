package com.example

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                Scaffold(
                    modifier = Modifier
                        .fillMaxSize()
                        .windowInsetsPadding(WindowInsets.safeDrawing)
                ) { innerPadding ->
                    AutoMacroMainScreen(
                        modifier = Modifier
                            .padding(innerPadding)
                            .navigationBarsPadding()
                    )
                }
            }
        }
    }
}

@Composable
fun AutoMacroMainScreen(modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val scrollState = rememberScrollState()

    // Service state observers
    val isAccessibilityActive by TouchAccessibilityService.isServiceConnected.collectAsState()
    val totalGestures by TouchAccessibilityService.totalGesturesExecuted.collectAsState()
    val lastGestureMsg by TouchAccessibilityService.lastGestureStatus.collectAsState()

    val macroStatusMsg by MacroFloatingService.macroState.collectAsState()
    val triggerCount by MacroFloatingService.triggerCount.collectAsState()
    val currentMode by MacroFloatingService.currentMode.collectAsState()

    var isOverlayPermissionGranted by remember { mutableStateOf(Settings.canDrawOverlays(context)) }
    var isServiceRunning by remember { mutableStateOf(MacroFloatingService.isServiceRunning) }

    // Check permissions on lifecycle return
    DisposableEffect(Unit) {
        val observer = androidx.lifecycle.LifecycleEventObserver { _, event ->
            if (event == androidx.lifecycle.Lifecycle.Event.ON_RESUME) {
                isOverlayPermissionGranted = Settings.canDrawOverlays(context)
                isServiceRunning = MacroFloatingService.isServiceRunning
            }
        }
        val lifecycle = (context as? ComponentActivity)?.lifecycle
        lifecycle?.addObserver(observer)
        onDispose {
            lifecycle?.removeObserver(observer)
        }
    }

    // MediaProjection screen capture launcher
    val projectionManager = remember {
        context.getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
    }

    val screenCaptureLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK && result.data != null) {
            val intent = Intent(context, MacroFloatingService::class.java).apply {
                action = MacroFloatingService.ACTION_START
                putExtra(MacroFloatingService.EXTRA_RESULT_CODE, result.resultCode)
                putExtra(MacroFloatingService.EXTRA_DATA_INTENT, result.data)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
            isServiceRunning = true
            Toast.makeText(context, "Macro Floating Service Started!", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(context, "Screen capture permission rejected", Toast.LENGTH_SHORT).show()
        }
    }

    var practiceTapCount by remember { mutableIntStateOf(0) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF0F111A)) // Deep Immersive UI background
            .verticalScroll(scrollState)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // --- Immersive App Bar ---
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(20.dp))
                .background(Color(0xFF1B1D29))
                .border(1.dp, Color(0x1AFFFFFF), RoundedCornerShape(20.dp))
                .padding(horizontal = 16.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Diamond rotated icon
                Box(
                    modifier = Modifier
                        .size(42.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color(0xFF6366F1)),
                    contentAlignment = Alignment.Center
                ) {
                    Box(
                        modifier = Modifier
                            .size(20.dp)
                            .rotate(45f)
                            .border(2.dp, Color.White, RoundedCornerShape(3.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Box(
                            modifier = Modifier
                                .size(5.dp)
                                .clip(CircleShape)
                                .background(Color.White)
                        )
                    }
                }

                Column {
                    Text(
                        text = "AutoMacro Pro",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        letterSpacing = (-0.5).sp
                    )
                    Text(
                        text = "v2.3.6 BUILD-402",
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        color = Color(0xFFA5B4FC),
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }

            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color(0x1AFFFFFF))
                    .padding(horizontal = 10.dp, vertical = 6.dp)
            ) {
                Text(
                    text = if (isServiceRunning) "ONLINE" else "OFFLINE",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (isServiceRunning) Color(0xFF34D399) else Color(0xFF94A3B8)
                )
            }
        }

        // --- Service Health Panel (2 Grid Cards) ---
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            HealthCard(
                title = "ACCESSIBILITY",
                status = if (isAccessibilityActive) "Service Active" else "Inactive",
                isOk = isAccessibilityActive,
                modifier = Modifier.weight(1f)
            )
            HealthCard(
                title = "OVERLAY",
                status = if (isOverlayPermissionGranted) "Permission OK" else "Missing",
                isOk = isOverlayPermissionGranted,
                modifier = Modifier.weight(1f)
            )
        }

        // --- Central Control Node (Glowing Pulsing Action Button) ---
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF1B1D29)),
            shape = RoundedCornerShape(28.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0x1AFFFFFF))
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Text(
                    text = "CENTRAL MACRO CONTROLLER",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    color = Color(0xFF94A3B8),
                    letterSpacing = 1.5.sp
                )

                PulsingControlButton(
                    isRunning = isServiceRunning,
                    onToggle = {
                        if (!isServiceRunning) {
                            if (!isOverlayPermissionGranted) {
                                Toast.makeText(context, "Enable Overlay Permission first", Toast.LENGTH_SHORT).show()
                                return@PulsingControlButton
                            }
                            if (!isAccessibilityActive) {
                                Toast.makeText(context, "Enable Accessibility Service first", Toast.LENGTH_SHORT).show()
                                return@PulsingControlButton
                            }
                            screenCaptureLauncher.launch(projectionManager.createScreenCaptureIntent())
                        } else {
                            val stopIntent = Intent(context, MacroFloatingService::class.java).apply {
                                action = MacroFloatingService.ACTION_STOP
                            }
                            context.startService(stopIntent)
                            isServiceRunning = false
                        }
                    }
                )

                Text(
                    text = if (isServiceRunning) "Floating Widget Floating Over Apps" else "Tap button to activate overlay macro engine",
                    fontSize = 12.sp,
                    color = Color(0xFFCBD5E1),
                    textAlign = TextAlign.Center
                )
            }
        }

        // --- Real-time Frame Analysis Console ---
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = Color(0x99000000)),
            shape = RoundedCornerShape(20.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0x1AFFFFFF))
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .clip(CircleShape)
                                .background(Color(0xFFEF4444))
                        )
                        Text(
                            text = "LIVE FRAME ANALYSIS",
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF64748B)
                        )
                    }
                    Text(
                        text = "60 FPS",
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        color = Color(0xFF818CF8)
                    )
                }

                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    ConsoleRow(label = "> SEARCH_TARGET:", value = "FISH_GAUGE", valueColor = Color(0xFF34D399))
                    ConsoleRow(label = "> MODE_ACTIVE:", value = getModeCode(currentMode), valueColor = Color.White)
                    ConsoleRow(label = "> GESTURES_SENT:", value = "$totalGestures TAPS", valueColor = Color(0xFF38BDF8))
                    ConsoleRow(label = "> TRIGGER_CYCLES:", value = "$triggerCount CYCLES", valueColor = Color(0xFFFBBF24))
                    ConsoleRow(label = "> LAST_STATUS:", value = lastGestureMsg, valueColor = Color(0xFFE2E8F0))
                }
            }
        }

        // --- Permission Step Rows ---
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF1B1D29)),
            shape = RoundedCornerShape(20.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0x1AFFFFFF))
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = "System Setup & Permissions",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )

                PermissionStepRow(
                    stepNumber = "1",
                    title = "System Overlay Permission",
                    desc = "Allows floating control buttons on top of other apps",
                    isGranted = isOverlayPermissionGranted,
                    onActionClick = {
                        val intent = Intent(
                            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                            Uri.parse("package:${context.packageName}")
                        )
                        context.startActivity(intent)
                    }
                )

                PermissionStepRow(
                    stepNumber = "2",
                    title = "Accessibility Touch Service",
                    desc = "Allows automated tap & hold dispatching without root",
                    isGranted = isAccessibilityActive,
                    onActionClick = {
                        val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
                        context.startActivity(intent)
                    }
                )
            }
        }

        // --- Select Macro Operation Mode ---
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF1B1D29)),
            shape = RoundedCornerShape(20.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0x1AFFFFFF))
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = "Macro Engine Preset",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    ModeOptionCard(
                        title = "Auto Clicker",
                        subtitle = "Rapid Tap",
                        isSelected = currentMode == MacroFloatingService.MODE_AUTO_CLICK,
                        onClick = { MacroFloatingService.setMacroMode(MacroFloatingService.MODE_AUTO_CLICK) },
                        modifier = Modifier.weight(1f)
                    )
                    ModeOptionCard(
                        title = "Pixel Fishing",
                        subtitle = "Gauge Scan",
                        isSelected = currentMode == MacroFloatingService.MODE_PIXEL_GAUGE,
                        onClick = { MacroFloatingService.setMacroMode(MacroFloatingService.MODE_PIXEL_GAUGE) },
                        modifier = Modifier.weight(1f)
                    )
                    ModeOptionCard(
                        title = "Color Trigger",
                        subtitle = "RGB Scan",
                        isSelected = currentMode == MacroFloatingService.MODE_COLOR_TRIGGER,
                        onClick = { MacroFloatingService.setMacroMode(MacroFloatingService.MODE_COLOR_TRIGGER) },
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }

        // --- Interactive Practice Target Area ---
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF1B1D29)),
            shape = RoundedCornerShape(20.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0x1AFFFFFF))
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = "Practice Target Sandbox",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
                Text(
                    text = "Move the floating crosshair target over this red circle to test real-time gesture triggering.",
                    fontSize = 12.sp,
                    color = Color(0xFF94A3B8)
                )

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(130.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .background(Color(0xFF0F111A))
                        .border(1.dp, Color(0xFF6366F1), RoundedCornerShape(14.dp))
                        .clickable { practiceTapCount += 1 },
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(50.dp)
                                .clip(CircleShape)
                                .background(Color(0xFFEF4444)),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "TARGET",
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        }
                        Text(
                            text = "Detected Taps: $practiceTapCount",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF38BDF8)
                        )
                    }
                }

                OutlinedButton(
                    onClick = { practiceTapCount = 0 },
                    modifier = Modifier.align(Alignment.End),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFF94A3B8))
                ) {
                    Text("Reset Counter", fontSize = 11.sp)
                }
            }
        }
    }
}

@Composable
fun HealthCard(title: String, status: String, isOk: Boolean, modifier: Modifier = Modifier) {
    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(containerColor = Color(0xFF1B1D29)),
        shape = RoundedCornerShape(20.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0x1AFFFFFF))
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Text(
                text = title,
                fontSize = 10.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF64748B),
                letterSpacing = 1.sp
            )
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(10.dp)
                        .clip(CircleShape)
                        .background(if (isOk) Color(0xFF34D399) else Color(0xFFEF4444))
                )
                Text(
                    text = status,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = Color.White
                )
            }
        }
    }
}

@Composable
fun PulsingControlButton(isRunning: Boolean, onToggle: () -> Unit) {
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = if (isRunning) 1.08f else 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(1000, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "scale"
    )

    Box(
        modifier = Modifier
            .size(150.dp)
            .scale(pulseScale)
            .clip(CircleShape)
            .background(
                Brush.linearGradient(
                    colors = if (isRunning) {
                        listOf(Color(0xFFEF4444), Color(0xFF991B1B))
                    } else {
                        listOf(Color(0xFF2563EB), Color(0xFF1D4ED8))
                    }
                )
            )
            .clickable { onToggle() },
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .rotate(45f)
                    .background(Color.White, RoundedCornerShape(8.dp)),
                contentAlignment = Alignment.Center
            ) {
                Box(
                    modifier = Modifier
                        .size(16.dp)
                        .rotate(-45f)
                        .background(
                            if (isRunning) Color(0xFF991B1B) else Color(0xFF1E40AF),
                            CircleShape
                        )
                )
            }
            Text(
                text = if (isRunning) "RUNNING" else "START",
                fontSize = 14.sp,
                fontWeight = FontWeight.Black,
                color = Color.White,
                letterSpacing = 1.5.sp
            )
        }
    }
}

@Composable
fun ConsoleRow(label: String, value: String, valueColor: Color) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(
            text = label,
            fontSize = 11.sp,
            fontFamily = FontFamily.Monospace,
            color = Color(0xFF94A3B8)
        )
        Text(
            text = value,
            fontSize = 11.sp,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            color = valueColor
        )
    }
}

private fun getModeCode(mode: Int): String {
    return when (mode) {
        MacroFloatingService.MODE_AUTO_CLICK -> "AUTO_TAP"
        MacroFloatingService.MODE_PIXEL_GAUGE -> "FISH_GAUGE"
        MacroFloatingService.MODE_COLOR_TRIGGER -> "COLOR_RGB"
        else -> "GENERIC"
    }
}

@Composable
fun PermissionStepRow(
    stepNumber: String,
    title: String,
    desc: String,
    isGranted: Boolean,
    onActionClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(Color(0xFF0F111A))
            .padding(12.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = "$stepNumber. $title",
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )
            Text(
                text = desc,
                fontSize = 11.sp,
                color = Color(0xFF94A3B8)
            )
        }

        Spacer(modifier = Modifier.width(8.dp))

        if (isGranted) {
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(6.dp))
                    .background(Color(0xFF065F46))
                    .padding(horizontal = 10.dp, vertical = 6.dp)
            ) {
                Text("Granted", fontSize = 11.sp, color = Color(0xFF34D399), fontWeight = FontWeight.Bold)
            }
        } else {
            Button(
                onClick = onActionClick,
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF6366F1))
            ) {
                Text("Enable", fontSize = 11.sp)
            }
        }
    }
}

@Composable
fun ModeOptionCard(
    title: String,
    subtitle: String,
    isSelected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier.clickable { onClick() },
        colors = CardDefaults.cardColors(
            containerColor = if (isSelected) Color(0xFF6366F1) else Color(0xFF0F111A)
        ),
        shape = RoundedCornerShape(12.dp),
        border = if (isSelected) androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFA5B4FC)) else null
    ) {
        Column(
            modifier = Modifier
                .padding(12.dp)
                .fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(2.dp)
        ) {
            Text(
                text = title,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White,
                textAlign = TextAlign.Center
            )
            Text(
                text = subtitle,
                fontSize = 10.sp,
                color = if (isSelected) Color(0xFFE0E7FF) else Color(0xFF94A3B8),
                textAlign = TextAlign.Center
            )
        }
    }
}

