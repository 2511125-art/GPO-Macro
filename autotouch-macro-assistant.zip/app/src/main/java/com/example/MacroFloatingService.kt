package com.example

import android.app.Activity
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.util.DisplayMetrics
import android.util.Log
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.nio.ByteBuffer
import kotlin.math.abs

/**
 * Foreground Service responsible for:
 * 1. Managing the Floating Overlay UI over other apps.
 * 2. Capturing real-time screen content via MediaProjection & ImageReader.
 * 3. Analyzing screen pixels and coordinating touch execution with TouchAccessibilityService.
 */
class MacroFloatingService : Service() {

    companion object {
        private const val TAG = "MacroFloatingService"
        private const val CHANNEL_ID = "MacroServiceChannel"
        private const val NOTIFICATION_ID = 1001

        const val ACTION_START = "com.example.ACTION_START"
        const val ACTION_STOP = "com.example.ACTION_STOP"
        const val EXTRA_RESULT_CODE = "RESULT_CODE"
        const val EXTRA_DATA_INTENT = "DATA_INTENT"

        // Macro Modes
        const val MODE_AUTO_CLICK = 0
        const val MODE_PIXEL_GAUGE = 1
        const val MODE_COLOR_TRIGGER = 2

        @Volatile
        var isServiceRunning = false
            private set

        private val _macroState = MutableStateFlow("Stopped")
        val macroState: StateFlow<String> = _macroState.asStateFlow()

        private val _triggerCount = MutableStateFlow(0)
        val triggerCount: StateFlow<Int> = _triggerCount.asStateFlow()

        private val _currentMode = MutableStateFlow(MODE_AUTO_CLICK)
        val currentMode: StateFlow<Int> = _currentMode.asStateFlow()

        private val _targetX = MutableStateFlow(540f)
        val targetX: StateFlow<Float> = _targetX.asStateFlow()

        private val _targetY = MutableStateFlow(1200f)
        val targetY: StateFlow<Float> = _targetY.asStateFlow()

        fun setMacroMode(mode: Int) {
            _currentMode.value = mode
        }

        fun setTargetCoordinates(x: Float, y: Float) {
            _targetX.value = x
            _targetY.value = y
        }
    }

    private lateinit var windowManager: WindowManager
    private var floatingView: View? = null
    private var crosshairView: View? = null

    private var floatingLayoutParams: WindowManager.LayoutParams? = null
    private var crosshairLayoutParams: WindowManager.LayoutParams? = null

    private var mediaProjection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null

    private var isMacroActive = false
    private var isMinimized = false

    private val handlerThread = HandlerThread("MacroLoopThread").apply { start() }
    private val backgroundHandler = Handler(handlerThread.looper)
    private val mainHandler = Handler(Looper.getMainLooper())

    private var screenWidth = 1080
    private var screenHeight = 2400
    private var screenDensity = 320

    override fun onCreate() {
        super.onCreate()
        isServiceRunning = true
        startForegroundNotification()
        initScreenMetrics()
        initFloatingWindow()
        initCrosshairWindow()
        _macroState.value = "Overlay Ready"
        Log.d(TAG, "MacroFloatingService created")
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopMacroAndService()
            return START_NOT_STICKY
        }

        val resultCode = intent?.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED) ?: Activity.RESULT_CANCELED
        val dataIntent: Intent? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            intent?.getParcelableExtra(EXTRA_DATA_INTENT, Intent::class.java)
        } else {
            @Suppress("DEPRECATION")
            intent?.getParcelableExtra(EXTRA_DATA_INTENT)
        }

        if (resultCode == Activity.RESULT_OK && dataIntent != null) {
            val projectionManager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            mediaProjection = projectionManager.getMediaProjection(resultCode, dataIntent)
            setupVirtualDisplay()
            _macroState.value = "Screen Capture Active"
        }

        return START_STICKY
    }

    private fun startForegroundNotification() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "AutoTouch Service",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Running macro floating controller and screen analyzer"
            }
            getSystemService(NotificationManager::class.java)?.createNotificationChannel(channel)
        }

        val stopIntent = Intent(this, MacroFloatingService::class.java).apply {
            action = ACTION_STOP
        }
        val stopPendingIntent = PendingIntent.getService(
            this, 0, stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val mainIntent = Intent(this, MainActivity::class.java)
        val mainPendingIntent = PendingIntent.getActivity(
            this, 0, mainIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification: Notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("AutoTouch Macro Active")
            .setContentText("Overlay control panel is floating on screen.")
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentIntent(mainPendingIntent)
            .addAction(R.drawable.ic_launcher_foreground, "Stop Service", stopPendingIntent)
            .setOngoing(true)
            .build()

        startForeground(NOTIFICATION_ID, notification)
    }

    private fun initScreenMetrics() {
        val metrics: DisplayMetrics = resources.displayMetrics
        screenWidth = metrics.widthPixels
        screenHeight = metrics.heightPixels
        screenDensity = metrics.densityDpi
        
        // Default target point at screen center
        _targetX.value = screenWidth / 2f
        _targetY.value = screenHeight / 2f
    }

    private fun initFloatingWindow() {
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager

        val overlayType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        floatingLayoutParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 80
            y = 250
        }

        // Create programmatic Overlay View
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#EE1E293B")) // Slate 800 dark semi-transparent
            setPadding(24, 20, 24, 20)
            elevation = 16f
        }

        // Header Drag Handle
        val headerLayout = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, 0, 0, 12)
        }

        val titleTv = TextView(this).apply {
            text = "⚡ AutoTouch"
            setTextColor(Color.WHITE)
            textSize = 14f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }

        val minBtn = Button(this).apply {
            text = "─"
            setTextColor(Color.LTGRAY)
            textSize = 12f
            setBackgroundColor(Color.TRANSPARENT)
            layoutParams = LinearLayout.LayoutParams(80, 80)
            setOnClickListener { toggleMinimize() }
        }

        headerLayout.addView(titleTv)
        headerLayout.addView(minBtn)

        // Status Text
        val statusTv = TextView(this).apply {
            text = "Status: Ready"
            setTextColor(Color.parseColor("#38BDF8")) // Sky blue
            textSize = 12f
            setPadding(0, 0, 0, 12)
        }

        // Mode Display
        val modeTv = TextView(this).apply {
            text = getModeName(_currentMode.value)
            setTextColor(Color.parseColor("#A7F3D0"))
            textSize = 11f
            setPadding(0, 0, 0, 12)
        }

        // Toggle Button
        val toggleBtn = Button(this).apply {
            text = "▶ START"
            setBackgroundColor(Color.parseColor("#2563EB")) // Vibrant Blue
            setTextColor(Color.WHITE)
            textSize = 13f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setOnClickListener { toggleMacroExecution(this, statusTv) }
        }

        container.addView(headerLayout)
        container.addView(statusTv)
        container.addView(modeTv)
        container.addView(toggleBtn)

        // Dragging Touch Listener
        var initialX = 0
        var initialY = 0
        var initialTouchX = 0f
        var initialTouchY = 0f

        headerLayout.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = floatingLayoutParams?.x ?: 0
                    initialY = floatingLayoutParams?.y ?: 0
                    initialTouchX = event.rawX
                    initialTouchY = event.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    floatingLayoutParams?.x = initialX + (event.rawX - initialTouchX).toInt()
                    floatingLayoutParams?.y = initialY + (event.rawY - initialTouchY).toInt()
                    windowManager.updateViewLayout(floatingView, floatingLayoutParams)
                    true
                }
                else -> false
            }
        }

        floatingView = container
        windowManager.addView(floatingView, floatingLayoutParams)
    }

    private fun initCrosshairWindow() {
        val overlayType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        crosshairLayoutParams = WindowManager.LayoutParams(
            120, 120,
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = (_targetX.value - 60).toInt()
            y = (_targetY.value - 60).toInt()
        }

        val crosshair = FrameLayout(this).apply {
            // Draw crosshair ring
            setBackgroundColor(Color.TRANSPARENT)
            val ringView = View(this@MacroFloatingService).apply {
                setBackgroundColor(Color.parseColor("#80EF4444")) // Red translucent target ring
            }
            val centerDot = View(this@MacroFloatingService).apply {
                setBackgroundColor(Color.RED)
                layoutParams = FrameLayout.LayoutParams(16, 16, Gravity.CENTER)
            }
            addView(ringView, FrameLayout.LayoutParams(120, 120))
            addView(centerDot)
        }

        crosshairView = crosshair
        try {
            windowManager.addView(crosshairView, crosshairLayoutParams)
        } catch (e: Exception) {
            Log.e(TAG, "Error adding crosshair window: ${e.message}")
        }
    }

    private fun getModeName(mode: Int): String {
        return when (mode) {
            MODE_AUTO_CLICK -> "Mode: Auto Clicker (Tap)"
            MODE_PIXEL_GAUGE -> "Mode: Fishing / Gauge Scan"
            MODE_COLOR_TRIGGER -> "Mode: Pixel Color Trigger"
            else -> "Mode: General Macro"
        }
    }

    private fun toggleMinimize() {
        isMinimized = !isMinimized
        val container = floatingView as? LinearLayout ?: return
        if (isMinimized) {
            for (i in 1 until container.childCount) {
                container.getChildAt(i).visibility = View.GONE
            }
        } else {
            for (i in 1 until container.childCount) {
                container.getChildAt(i).visibility = View.VISIBLE
            }
        }
    }

    private fun setupVirtualDisplay() {
        try {
            imageReader = ImageReader.newInstance(screenWidth, screenHeight, PixelFormat.RGBA_8888, 2)
            virtualDisplay = mediaProjection?.createVirtualDisplay(
                "AutoTouchScreenCapture",
                screenWidth,
                screenHeight,
                screenDensity,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                imageReader?.surface,
                null,
                null
            )
            Log.d(TAG, "Virtual display setup completed successfully")
        } catch (e: Exception) {
            Log.e(TAG, "Failed to setup VirtualDisplay: ${e.message}")
        }
    }

    private fun toggleMacroExecution(button: Button, statusTv: TextView) {
        isMacroActive = !isMacroActive

        if (isMacroActive) {
            button.text = "⏹ STOP"
            button.setBackgroundColor(Color.parseColor("#DC2626")) // Red
            statusTv.text = "Status: Running"
            _macroState.value = "Running"
            backgroundHandler.post(macroRunnable)
        } else {
            button.text = "▶ START"
            button.setBackgroundColor(Color.parseColor("#2563EB")) // Vibrant Blue
            statusTv.text = "Status: Paused"
            _macroState.value = "Paused"
            backgroundHandler.removeCallbacks(macroRunnable)
        }
    }

    private val macroRunnable = object : Runnable {
        override fun run() {
            if (!isMacroActive) return

            when (_currentMode.value) {
                MODE_AUTO_CLICK -> runAutoClickerMode()
                MODE_PIXEL_GAUGE -> runPixelGaugeMode()
                MODE_COLOR_TRIGGER -> runColorTriggerMode()
            }

            // Schedule next execution cycle (150ms default loop)
            if (isMacroActive) {
                backgroundHandler.postDelayed(this, 150L)
            }
        }
    }

    private fun runAutoClickerMode() {
        val touchService = TouchAccessibilityService.instance
        if (touchService != null) {
            val tapX = _targetX.value
            val tapY = _targetY.value
            touchService.performTap(tapX, tapY)
            _triggerCount.value += 1
            updateStatusText("Auto Tap ($tapX, $tapY)")
        } else {
            updateStatusText("Accessibility Svc Inactive!")
        }
    }

    private fun runPixelGaugeMode() {
        val image = imageReader?.acquireLatestImage() ?: return
        try {
            val planes = image.planes
            val buffer: ByteBuffer = planes[0].buffer
            val pixelStride = planes[0].pixelStride
            val rowStride = planes[0].rowStride
            val rowPadding = rowStride - pixelStride * screenWidth

            val bitmap = Bitmap.createBitmap(
                screenWidth + rowPadding / pixelStride,
                screenHeight,
                Bitmap.Config.ARGB_8888
            )
            bitmap.copyPixelsFromBuffer(buffer)

            val searchX = screenWidth / 2
            var targetY = -1
            var playerY = -1

            val startY = (screenHeight * 0.3).toInt()
            val endY = (screenHeight * 0.8).toInt()

            for (y in startY..endY step 6) {
                if (searchX < bitmap.width && y < bitmap.height) {
                    val pixel = bitmap.getPixel(searchX, y)
                    val r = Color.red(pixel)
                    val g = Color.green(pixel)
                    val b = Color.blue(pixel)

                    // Target indicator color (Red hue)
                    if (r > 200 && g < 70 && b < 70) {
                        targetY = y
                    }
                    // Player bar color (Dark or distinct blue/green)
                    if (r < 40 && g < 40 && b < 40) {
                        playerY = y
                    }
                }
            }

            bitmap.recycle()

            val touchService = TouchAccessibilityService.instance
            if (touchService != null) {
                if (targetY != -1 && playerY != -1) {
                    if (targetY < playerY) {
                        // Hold screen to push bar up
                        touchService.performHold(searchX.toFloat(), screenHeight * 0.5f, 160L)
                        _triggerCount.value += 1
                        updateStatusText("Gauge Hold ↑")
                    } else {
                        updateStatusText("Gauge Balance ↓")
                    }
                } else if (targetY == -1 && playerY == -1) {
                    // Tap to cast or interact
                    touchService.performTap(searchX.toFloat(), screenHeight * 0.7f)
                    _triggerCount.value += 1
                    updateStatusText("Cast Tap")
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error in pixel gauge scan: ${e.message}")
        } finally {
            image.close()
        }
    }

    private fun runColorTriggerMode() {
        val image = imageReader?.acquireLatestImage() ?: return
        try {
            val planes = image.planes
            val buffer: ByteBuffer = planes[0].buffer
            val pixelStride = planes[0].pixelStride
            val rowStride = planes[0].rowStride
            val rowPadding = rowStride - pixelStride * screenWidth

            val bitmap = Bitmap.createBitmap(
                screenWidth + rowPadding / pixelStride,
                screenHeight,
                Bitmap.Config.ARGB_8888
            )
            bitmap.copyPixelsFromBuffer(buffer)

            val checkX = _targetX.value.toInt().coerceIn(0, bitmap.width - 1)
            val checkY = _targetY.value.toInt().coerceIn(0, bitmap.height - 1)

            val pixel = bitmap.getPixel(checkX, checkY)
            val r = Color.red(pixel)
            val g = Color.green(pixel)
            val b = Color.blue(pixel)

            bitmap.recycle()

            // Trigger action if brightness or red accent exceeds threshold
            if (r > 180 || (r > 150 && g > 150)) {
                TouchAccessibilityService.instance?.performTap(checkX.toFloat(), checkY.toFloat())
                _triggerCount.value += 1
                updateStatusText("Triggered at ($checkX, $checkY)")
            } else {
                updateStatusText("Scanning RGB($r,$g,$b)")
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error in color trigger scan: ${e.message}")
        } finally {
            image.close()
        }
    }

    private fun updateStatusText(msg: String) {
        mainHandler.post {
            val container = floatingView as? LinearLayout ?: return@post
            if (container.childCount > 1) {
                val statusTv = container.getChildAt(1) as? TextView
                statusTv?.text = "Status: $msg"
            }
        }
    }

    private fun stopMacroAndService() {
        isMacroActive = false
        isServiceRunning = false
        _macroState.value = "Stopped"

        backgroundHandler.removeCallbacks(macroRunnable)

        try {
            floatingView?.let { windowManager.removeView(it) }
            crosshairView?.let { windowManager.removeView(it) }
        } catch (e: Exception) {
            Log.e(TAG, "Error removing floating views: ${e.message}")
        }

        virtualDisplay?.release()
        mediaProjection?.stop()
        handlerThread.quit()

        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        super.onDestroy()
        stopMacroAndService()
        Log.d(TAG, "MacroFloatingService destroyed")
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
