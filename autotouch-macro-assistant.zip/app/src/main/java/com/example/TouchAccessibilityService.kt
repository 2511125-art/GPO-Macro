package com.example

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Build
import android.util.Log
import android.view.accessibility.AccessibilityEvent
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Touch Accessibility Service responsible for programmatically dispatching touch gestures
 * (Tap, Hold, Swipe) using standard Android Accessibility APIs without root.
 */
class TouchAccessibilityService : AccessibilityService() {

    companion object {
        private const val TAG = "TouchAccessibilitySvc"

        @Volatile
        var instance: TouchAccessibilityService? = null
            private set

        private val _isServiceConnected = MutableStateFlow(false)
        val isServiceConnected: StateFlow<Boolean> = _isServiceConnected.asStateFlow()

        private val _totalGesturesExecuted = MutableStateFlow(0)
        val totalGesturesExecuted: StateFlow<Int> = _totalGesturesExecuted.asStateFlow()

        private val _lastGestureStatus = MutableStateFlow("Service Idle")
        val lastGestureStatus: StateFlow<String> = _lastGestureStatus.asStateFlow()
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        _isServiceConnected.value = true
        _lastGestureStatus.value = "Accessibility Service Connected"
        Log.d(TAG, "TouchAccessibilityService connected successfully")
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Optional: Can process window state changes if required
    }

    override fun onInterrupt() {
        Log.w(TAG, "TouchAccessibilityService interrupted")
        _lastGestureStatus.value = "Service Interrupted"
    }

    override fun onDestroy() {
        super.onDestroy()
        instance = null
        _isServiceConnected.value = false
        _lastGestureStatus.value = "Service Destroyed"
        Log.d(TAG, "TouchAccessibilityService destroyed")
    }

    /**
     * Dispatch a single tap at the specified (x, y) coordinates.
     * Default duration is 50ms.
     */
    fun performTap(x: Float, y: Float, durationMs: Long = 50L, onComplete: ((Boolean) -> Unit)? = null) {
        val path = Path().apply {
            moveTo(x, y)
        }
        val stroke = GestureDescription.StrokeDescription(path, 0, durationMs.coerceAtLeast(10L))
        val gesture = GestureDescription.Builder().addStroke(stroke).build()

        dispatchGestureInternal(gesture, "Tap ($x, $y)", onComplete)
    }

    /**
     * Dispatch a long press / hold at the specified (x, y) coordinates for durationMs.
     */
    fun performHold(x: Float, y: Float, durationMs: Long, onComplete: ((Boolean) -> Unit)? = null) {
        val path = Path().apply {
            moveTo(x, y)
        }
        val stroke = GestureDescription.StrokeDescription(path, 0, durationMs.coerceAtLeast(50L))
        val gesture = GestureDescription.Builder().addStroke(stroke).build()

        dispatchGestureInternal(gesture, "Hold ($x, $y) for ${durationMs}ms", onComplete)
    }

    /**
     * Dispatch a swipe gesture from (startX, startY) to (endX, endY) over durationMs.
     */
    fun performSwipe(
        startX: Float,
        startY: Float,
        endX: Float,
        endY: Float,
        durationMs: Long = 300L,
        onComplete: ((Boolean) -> Unit)? = null
    ) {
        val path = Path().apply {
            moveTo(startX, startY)
            lineTo(endX, endY)
        }
        val stroke = GestureDescription.StrokeDescription(path, 0, durationMs.coerceAtLeast(50L))
        val gesture = GestureDescription.Builder().addStroke(stroke).build()

        dispatchGestureInternal(gesture, "Swipe ($startX, $startY) -> ($endX, $endY)", onComplete)
    }

    private fun dispatchGestureInternal(
        gesture: GestureDescription,
        actionName: String,
        onComplete: ((Boolean) -> Unit)?
    ) {
        val dispatched = dispatchGesture(gesture, object : GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) {
                super.onCompleted(gestureDescription)
                _totalGesturesExecuted.value += 1
                _lastGestureStatus.value = "Success: $actionName"
                Log.d(TAG, "Gesture completed: $actionName")
                onComplete?.invoke(true)
            }

            override fun onCancelled(gestureDescription: GestureDescription?) {
                super.onCancelled(gestureDescription)
                _lastGestureStatus.value = "Cancelled: $actionName"
                Log.w(TAG, "Gesture cancelled: $actionName")
                onComplete?.invoke(false)
            }
        }, null)

        if (!dispatched) {
            _lastGestureStatus.value = "Failed to dispatch: $actionName"
            Log.e(TAG, "Failed to dispatch gesture: $actionName")
            onComplete?.invoke(false)
        }
    }
}
